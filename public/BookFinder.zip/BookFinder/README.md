# Book Finder

A small menu bar app for macOS 13 or later. Click the book icon, type a title, and download free, legal EPUBs from Project Gutenberg and the Internet Archive. They're saved to your Downloads folder.

## Setup (one time)
1. Install Apple's command line tools (no Xcode needed): `xcode-select --install`
2. In Terminal, go to this folder and run `./build.sh`
3. Move the app: `cp -R BookFinder.app /Applications/`
4. Start it: `open /Applications/BookFinder.app`

To start it automatically, add Book Finder in System Settings → General → Login Items.
