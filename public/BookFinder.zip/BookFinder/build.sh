#!/bin/bash
# Builds Book Finder and wraps it into a normal Mac app (BookFinder.app).
set -euo pipefail
cd "$(dirname "$0")"

pkill -x BookFinder 2>/dev/null || true  # quit any copy that is already running
echo "Building Book Finder (this takes a minute the first time)…"
swift build -c release

APP="BookFinder.app"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS"
cp .build/release/BookFinder "$APP/Contents/MacOS/BookFinder"

cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key><string>BookFinder</string>
    <key>CFBundleIdentifier</key><string>local.bookfinder</string>
    <key>CFBundleName</key><string>Book Finder</string>
    <key>CFBundlePackageType</key><string>APPL</string>
    <key>CFBundleShortVersionString</key><string>1.0</string>
    <key>CFBundleVersion</key><string>1</string>
    <key>LSMinimumSystemVersion</key><string>13.0</string>
    <key>LSUIElement</key><true/>
    <key>NSHighResolutionCapable</key><true/>
</dict>
</plist>
PLIST

codesign --force --sign - "$APP" >/dev/null 2>&1 || true
echo "Done! Your app is at: $(pwd)/$APP"
