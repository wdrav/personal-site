// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "BookFinder",
    platforms: [.macOS(.v13)],
    targets: [
        .executableTarget(name: "BookFinder", path: "Sources/BookFinder")
    ]
)
