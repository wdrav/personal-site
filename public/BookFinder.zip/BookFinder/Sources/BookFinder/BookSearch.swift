import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
#if canImport(FoundationXML)
import FoundationXML
#endif

enum Source: String, CaseIterable {
    case standardEbooks = "Standard Ebooks"
    case gutenberg = "Project Gutenberg"
    case wikisource = "Wikisource"
    case archive = "Internet Archive"

    /// Short description shown under each result.
    var note: String {
        switch self {
        case .standardEbooks: return "Standard Ebooks · professionally formatted"
        case .gutenberg: return "Project Gutenberg · proofread"
        case .wikisource: return "Wikisource · proofread"
        case .archive: return "Internet Archive · scanned book"
        }
    }
}

struct Book: Identifiable, Hashable {
    let id: String
    let title: String
    let author: String
    let source: Source
    let downloadURL: URL?  // Direct EPUB link (everything except Internet Archive)
    let archiveID: String? // Internet Archive: files are looked up at download time
}

/// What happened during a download, shown to the person afterwards.
struct DownloadResult {
    let file: URL
    var summary: String
}

enum BookError: LocalizedError {
    case noEPUB
    case badResponse(Int)

    var errorDescription: String? {
        switch self {
        case .noEPUB: return "No EPUB file was found for this book."
        case .badResponse(let code): return "The site responded with error \(code)."
        }
    }
}

enum BookSearch {

    // MARK: Search every source at the same time; best-formatted sources first

    static func search(_ query: String) async -> [Book] {
        async let se: [Book] = (try? await standardEbooks(query)) ?? []
        async let g: [Book] = (try? await gutenberg(query)) ?? []
        async let ws: [Book] = (try? await wikisource(query)) ?? []
        async let a: [Book] = (try? await archive(query)) ?? []
        return await se + g + ws + a
    }

    // MARK: Standard Ebooks (OPDS catalog feed)

    static func standardEbooks(_ query: String) async throws -> [Book] {
        var c = URLComponents(string: "https://standardebooks.org/feeds/opds/all")!
        c.queryItems = [URLQueryItem(name: "query", value: query), URLQueryItem(name: "per-page", value: "12")]
        let data = try await fetchData(c.url!)
        return OPDSParser.parse(data).map { e in
            Book(id: "se-\(e.id)", title: e.title, author: e.author.ifEmpty("Unknown author"),
                 source: .standardEbooks, downloadURL: e.epub, archiveID: nil)
        }
    }

    // MARK: Project Gutenberg (via the Gutendex catalog)

    private struct GResponse: Decodable { let results: [GBook] }
    private struct GBook: Decodable {
        let id: Int
        let title: String
        let authors: [GAuthor]
        let formats: [String: String]
    }
    private struct GAuthor: Decodable { let name: String }

    static func gutenberg(_ query: String) async throws -> [Book] {
        var c = URLComponents(string: "https://gutendex.com/books/")!
        c.queryItems = [URLQueryItem(name: "search", value: query)]
        let response: GResponse = try await fetchJSON(c.url!)
        return response.results.compactMap { b in
            guard let link = b.formats["application/epub+zip"], let url = URL(string: link) else { return nil }
            return Book(id: "g-\(b.id)", title: b.title,
                        author: b.authors.map(\.name).joined(separator: "; ").ifEmpty("Unknown author"),
                        source: .gutenberg, downloadURL: url, archiveID: nil)
        }
    }

    // MARK: Wikisource (proofread transcriptions, turned into EPUBs by WS Export)

    private struct WSResponse: Decodable { let query: WSQuery? }
    private struct WSQuery: Decodable { let pages: [WSPage] }
    private struct WSPage: Decodable {
        let title: String
        let index: Int?
        let categories: [WSCategory]?
    }
    private struct WSCategory: Decodable { let title: String }

    static func wikisource(_ query: String) async throws -> [Book] {
        var c = URLComponents(string: "https://en.wikisource.org/w/api.php")!
        c.queryItems = [
            URLQueryItem(name: "action", value: "query"),
            URLQueryItem(name: "generator", value: "search"),
            URLQueryItem(name: "gsrsearch", value: "intitle:\(query)"),
            URLQueryItem(name: "gsrnamespace", value: "0"),
            URLQueryItem(name: "gsrlimit", value: "40"),
            URLQueryItem(name: "prop", value: "categories"),
            URLQueryItem(name: "cllimit", value: "max"),
            URLQueryItem(name: "format", value: "json"),
            URLQueryItem(name: "formatversion", value: "2"),
        ]
        let response: WSResponse = try await fetchJSON(c.url!)
        let pages = (response.query?.pages ?? []).sorted { ($0.index ?? 0) < ($1.index ?? 0) }
        return pages.compactMap { p in
            // Keep whole works only: skip chapters ("Title/Chapter 1"), lists of versions, and disambiguation pages.
            let cats = (p.categories ?? []).map(\.title)
            guard !p.title.contains("/"),
                  !cats.contains(where: { $0.contains("Versions pages") || $0.contains("Disambiguation") }),
                  cats.contains(where: { $0.range(of: #"\d{4} works|PD-"#, options: .regularExpression) != nil })
            else { return nil }
            var e = URLComponents(string: "https://ws-export.wmcloud.org/")!
            e.queryItems = [URLQueryItem(name: "format", value: "epub"), URLQueryItem(name: "lang", value: "en"),
                            URLQueryItem(name: "page", value: p.title.replacingOccurrences(of: " ", with: "_"))]
            return Book(id: "ws-\(p.title)", title: p.title, author: "", source: .wikisource,
                        downloadURL: e.url, archiveID: nil)
        }
        .prefix(8).map { $0 }
    }

    // MARK: Internet Archive (freely downloadable items only, no lending-library books)

    private struct AResponse: Decodable { let response: ADocs }
    private struct ADocs: Decodable { let docs: [ADoc] }
    private struct ADoc: Decodable {
        let identifier: String
        let title: String?
        let creator: StringOrList?
    }
    private enum StringOrList: Decodable {
        case one(String), many([String])
        init(from decoder: Decoder) throws {
            let c = try decoder.singleValueContainer()
            if let s = try? c.decode(String.self) { self = .one(s) }
            else { self = .many((try? c.decode([String].self)) ?? []) }
        }
        var text: String {
            switch self {
            case .one(let s): return s
            case .many(let list): return list.joined(separator: "; ")
            }
        }
    }

    static func archive(_ query: String) async throws -> [Book] {
        let cleaned = query.filter { $0.isLetter || $0.isNumber || $0 == " " }
        guard !cleaned.trimmingCharacters(in: .whitespaces).isEmpty else { return [] }
        let q = "title:(\(cleaned)) AND mediatype:texts AND format:EPUB"
            + " AND NOT collection:(inlibrary OR printdisabled OR lendinglibrary)"
            + " AND NOT access-restricted-item:true"
        var c = URLComponents(string: "https://archive.org/advancedsearch.php")!
        c.queryItems = [
            URLQueryItem(name: "q", value: q),
            URLQueryItem(name: "fl[]", value: "identifier"),
            URLQueryItem(name: "fl[]", value: "title"),
            URLQueryItem(name: "fl[]", value: "creator"),
            URLQueryItem(name: "sort[]", value: "downloads desc"),
            URLQueryItem(name: "rows", value: "15"),
            URLQueryItem(name: "output", value: "json"),
        ]
        let response: AResponse = try await fetchJSON(c.url!)
        return response.response.docs.map { d in
            Book(id: "a-\(d.identifier)", title: d.title ?? d.identifier,
                 author: (d.creator?.text ?? "").ifEmpty("Unknown author"),
                 source: .archive, downloadURL: nil, archiveID: d.identifier)
        }
    }

    private struct AMeta: Decodable { let files: [AFile]? }
    private struct AFile: Decodable { let name: String; let format: String? }

    private static func archiveFiles(_ id: String) async throws -> [AFile] {
        let meta: AMeta = try await fetchJSON(URL(string: "https://archive.org/metadata/\(id)")!)
        return meta.files ?? []
    }

    private static func archiveURL(_ id: String, _ file: String) -> URL {
        URL(string: "https://archive.org/download/\(id)/")!.appendingPathComponent(file)
    }

    // MARK: Download into the Downloads folder

    /// `improve`: rebuild scanned (Internet Archive) books from their page-layout data.
    static func download(_ book: Book, improve: Bool, to folder: URL? = nil) async throws -> DownloadResult {
        let fm = FileManager.default
        let work = fm.temporaryDirectory.appendingPathComponent("bookfinder-\(UUID().uuidString)")
        try fm.createDirectory(at: work, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: work) }

        var finished: URL
        var summary: String

        if let url = book.downloadURL {
            finished = work.appendingPathComponent("book.epub")
            try await fetchData(url, timeout: 120).write(to: finished)
            summary = "Downloaded the \(book.source.rawValue) edition."
        } else if let id = book.archiveID {
            let files = try await archiveFiles(id)
            if improve, let rebuilt = try? await rebuildFromScan(book, id: id, files: files, work: work) {
                (finished, summary) = rebuilt
            } else {
                // Fall back to the Archive's own EPUB, with typo cleanup.
                guard let epub = files.first(where: { $0.name.lowercased().hasSuffix(".epub") }) else {
                    throw BookError.noEPUB
                }
                let original = work.appendingPathComponent("original.epub")
                try await fetchData(archiveURL(id, epub.name), timeout: 120).write(to: original)
                finished = original
                summary = "Downloaded the Archive's own EPUB."
                if improve {
                    let cleaned = work.appendingPathComponent("cleaned.epub")
                    if let n = try? EpubCleaner.clean(original, to: cleaned) {
                        finished = cleaned
                        summary = "No page-layout data was available, so the Archive's EPUB was used and \(n) scanning errors were fixed."
                    }
                }
            }
        } else {
            throw BookError.noEPUB
        }

        let dest = uniqueDestination(for: book.title, in: folder ?? fm.urls(for: .downloadsDirectory, in: .userDomainMask)[0])
        try fm.moveItem(at: finished, to: dest)
        return DownloadResult(file: dest, summary: summary)
    }

    /// Downloads the scan's page-layout file and rebuilds a properly formatted EPUB from it.
    private static func rebuildFromScan(_ book: Book, id: String, files: [AFile], work: URL) async throws -> (URL, String) {
        let fm = FileManager.default
        let layout: URL
        let kind: ScanReader.Kind
        if let abbyy = files.first(where: { $0.name.hasSuffix("_abbyy.gz") || $0.format == "Abbyy GZ" }) {
            let gz = work.appendingPathComponent("layout.xml.gz")
            try await fetchData(archiveURL(id, abbyy.name), timeout: 180).write(to: gz)
            try Shell.run("/usr/bin/gunzip", ["-f", gz.path])
            layout = work.appendingPathComponent("layout.xml")
            kind = .abbyy
        } else if let hocr = files.first(where: { $0.name.hasSuffix("_hocr.html") }) {
            layout = work.appendingPathComponent("layout.html")
            try await fetchData(archiveURL(id, hocr.name), timeout: 180).write(to: layout)
            kind = .hocr
        } else {
            throw BookError.noEPUB
        }
        guard fm.fileExists(atPath: layout.path) else { throw BookError.noEPUB }

        let pages = try ScanReader.read(layout, kind: kind)
        let output = work.appendingPathComponent("rebuilt.epub")
        let report = try ScanRebuilder.rebuild(pages: pages, title: book.title, author: book.author, to: output, work: work)
        return (output, "Rebuilt from the original scan: \(report.chapters) chapters, \(report.paragraphs) paragraphs, \(report.italics) italic passages, \(report.removed) page headers and numbers removed.")
    }

    // MARK: Helpers

    private static func uniqueDestination(for title: String, in folder: URL) -> URL {
        let base = safeFileName(title)
        var dest = folder.appendingPathComponent("\(base).epub")
        var n = 2
        while FileManager.default.fileExists(atPath: dest.path) {
            dest = folder.appendingPathComponent("\(base) (\(n)).epub")
            n += 1
        }
        return dest
    }

    static func fetchData(_ url: URL, timeout: TimeInterval = 20) async throws -> Data {
        var request = URLRequest(url: url)
        request.timeoutInterval = timeout
        request.setValue("BookFinder/1.0 (personal reading app)", forHTTPHeaderField: "User-Agent")
        // Busy sites sometimes ask us to slow down (429/503); wait a moment and try again.
        for attempt in 0..<3 {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) else { return data }
            if [429, 503].contains(http.statusCode) && attempt < 2 {
                try await Task.sleep(nanoseconds: UInt64(attempt + 1) * 2_000_000_000)
                continue
            }
            throw BookError.badResponse(http.statusCode)
        }
        throw BookError.badResponse(503)
    }

    private static func fetchJSON<T: Decodable>(_ url: URL) async throws -> T {
        try JSONDecoder().decode(T.self, from: try await fetchData(url))
    }

    private static func safeFileName(_ title: String) -> String {
        let bad = CharacterSet(charactersIn: "/\\:?%*|\"<>\n\r\t")
        let cleaned = title.components(separatedBy: bad).joined(separator: " ")
            .trimmingCharacters(in: .whitespaces)
        return String(cleaned.prefix(120)).ifEmpty("Book")
    }
}

/// Reads the Standard Ebooks catalog feed (Atom/OPDS XML).
final class OPDSParser: NSObject, XMLParserDelegate {
    struct Entry { var id = "", title = "", author = "", epub: URL? }
    private var entries: [Entry] = []
    private var current: Entry?
    private var text = ""
    private var inAuthor = false

    static func parse(_ data: Data) -> [Entry] {
        let p = OPDSParser()
        let parser = XMLParser(data: data)
        parser.delegate = p
        _ = parser.parse()
        return p.entries.filter { $0.epub != nil }
    }

    func parser(_ parser: XMLParser, didStartElement name: String, namespaceURI: String?,
                qualifiedName: String?, attributes: [String: String] = [:]) {
        text = ""
        switch name {
        case "entry": current = Entry()
        case "author": inAuthor = true
        case "link":
            if current?.epub == nil, attributes["type"] == "application/epub+zip",
               let href = attributes["href"] {
                current?.epub = URL(string: href)
            }
        default: break
        }
    }

    func parser(_ parser: XMLParser, foundCharacters string: String) { text += string }

    func parser(_ parser: XMLParser, didEndElement name: String, namespaceURI: String?, qualifiedName: String?) {
        let value = text.trimmingCharacters(in: .whitespacesAndNewlines)
        switch name {
        case "entry": if let e = current { entries.append(e) }; current = nil
        case "id": current?.id = value
        case "title": current?.title = value
        case "name": if inAuthor, current?.author.isEmpty == true { current?.author = value }
        case "author": inAuthor = false
        default: break
        }
        text = ""
    }
}

/// Runs a built-in command-line tool (unzip, zip, gunzip).
enum Shell {
    struct Failed: LocalizedError {
        let tool: String
        var errorDescription: String? { "The \(tool) step failed." }
    }

    static func run(_ tool: String, _ args: [String], in dir: URL? = nil, okCodes: Set<Int32> = [0]) throws {
        let p = Process()
        p.executableURL = URL(fileURLWithPath: tool)
        p.arguments = args
        if let dir { p.currentDirectoryURL = dir }
        p.standardOutput = FileHandle.nullDevice
        p.standardError = FileHandle.nullDevice
        try p.run()
        p.waitUntilExit()
        guard okCodes.contains(p.terminationStatus) else {
            throw Failed(tool: URL(fileURLWithPath: tool).lastPathComponent)
        }
    }
}

extension String {
    func ifEmpty(_ fallback: String) -> String { isEmpty ? fallback : self }
}
