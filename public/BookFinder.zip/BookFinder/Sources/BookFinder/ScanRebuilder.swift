import Foundation

/// Turns scanned pages into a properly structured EPUB: real paragraphs,
/// chapter headings, italics, a table of contents, and no page headers or numbers.
enum ScanRebuilder {

    struct Report {
        var chapters = 0
        var paragraphs = 0
        var italics = 0
        var removed = 0
    }

    private struct Block {
        enum Kind { case heading, paragraph }
        var kind: Kind
        var chars: [(Character, Bool)] // each character and whether it's italic
        var plain: String { String(chars.map(\.0)) }
    }

    // MARK: Main entry point

    static func rebuild(pages: [ScanPage], title: String, author: String, to output: URL, work: URL) throws -> Report {
        var report = Report()
        let blocks = fixHeadings(structure(pages, title: title, report: &report), report: &report)
        guard blocks.contains(where: { $0.kind == .paragraph }) else { throw BookError.noEPUB }
        let chapters = splitIntoChapters(blocks)
        report.chapters = chapters.filter { $0.heading != nil }.count
        report.paragraphs = blocks.filter { $0.kind == .paragraph }.count
        try EpubWriter.write(title: title, author: author, chapters: chapters, to: output, work: work)
        return report
    }

    // MARK: Pages → headings and paragraphs

    private static let chapterPattern = try! NSRegularExpression(
        pattern: #"^(chapter|book|part|volume|canto|act|scene|letter|section)\s+([ivxlcdm]+|\d+|one|two|three|four|five|six|seven|eight|nine|ten|the\s+\w+)\b[.:]?"#,
        options: [.caseInsensitive])
    private static let leaderPattern = try! NSRegularExpression(pattern: #"(\.\s*){4,}"#)

    private static func structure(_ pages: [ScanPage], title: String, report: inout Report) -> [Block] {
        let bodySize = typicalFontSize(pages)
        let repeated = repeatedEdgeLines(pages)

        // Does this book mark new paragraphs by indenting their first line?
        var indented = 0, multiLine = 0
        for page in pages {
            for p in page.pars where p.lines.count >= 2 {
                multiLine += 1
                if p.lines[0].left - p.lines[1].left > page.width * 0.015 { indented += 1 }
            }
        }
        let usesIndents = multiLine > 0 && Double(indented) / Double(multiLine) > 0.4

        var blocks: [Block] = []
        for page in pages {
            let pars = page.pars.sorted { $0.top < $1.top }
            let columnLeft = median(pars.flatMap { $0.lines.count >= 2 ? $0.lines.map(\.left) : [] })
                ?? median(pars.flatMap { $0.lines.map(\.left) }) ?? 0
            let columnRight = median(pars.flatMap { $0.lines.map(\.right) }) ?? page.width
            var firstOnPage = true

            for (i, par) in pars.enumerated() {
                let text = par.lines.map(\.text).joined(separator: " ")
                    .trimmingCharacters(in: .whitespacesAndNewlines)
                let oneLine = par.lines.count == 1

                // Page headers and footers: single lines at the very top or bottom.
                let atTop = i == 0 && par.top < page.height * 0.12
                let atBottom = i == pars.count - 1 && par.top > page.height * 0.85
                let isChapterTitle = chapterPattern.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)) != nil
                    || isChapterLike(text)
                if oneLine && (atTop || atBottom) && !isChapterTitle {
                    let maxSize = par.lines[0].runs.map(\.size).max() ?? 0
                    if text.rangeOfCharacter(from: .decimalDigits) != nil
                        || repeated.contains(normalized(text))
                        || (bodySize > 0 && maxSize < bodySize * 0.9 && text.count < 70) {
                        report.removed += 1
                        continue
                    }
                }
                if isPageNumber(text) { report.removed += 1; continue }
                // Share of words the scanner found in its dictionary (garbled text scores low).
                let words = par.lines.reduce(0) { $0 + $1.words }
                let known = par.lines.reduce(0) { $0 + $1.dictionaryWords }
                let hasInfo = par.lines.contains { $0.hasDictionaryInfo } && words > 0
                let realWords = hasInfo ? Double(known) / Double(words) : 1
                if !isChapterTitle && (isJunk(text) || (hasInfo && words >= 2 && realWords < 0.3)) { continue }
                if repeated.contains(normalized(text)) && text.count < 70 && oneLine {
                    report.removed += 1 // running header that wasn't at the very top
                    continue
                }
                if leaderPattern.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)) != nil {
                    continue // lines of an old printed contents page; we build our own
                }

                let chars = joinLines(par.lines)
                let maxSize = par.lines.flatMap { $0.runs.map(\.size) }.max() ?? 0
                let isIndented = par.lines.count >= 2
                    ? par.lines[0].left - par.lines[1].left > page.width * 0.015
                    : par.lines[0].left - columnLeft > page.width * 0.015
                let leftGap = par.lines[0].left - columnLeft
                let rightGap = columnRight - par.lines[0].right
                let centered = oneLine && leftGap > page.width * 0.06 && rightGap > page.width * 0.06
                    && abs(leftGap - rightGap) < page.width * 0.08

                // "CHAPTER XLVII. It was..." — a heading printed on the same line as the text.
                if let m = chapterPattern.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
                   let r = Range(m.range, in: text), text[r.upperBound...].trimmingCharacters(in: .whitespaces).count > 30 {
                    let cut = text.distance(from: text.startIndex, to: r.upperBound)
                    let rest = Array(chars.dropFirst(cut)).drop { $0.0 == " " || $0.0 == "." }
                    blocks.append(Block(kind: .heading, chars: Array(chars.prefix(cut))))
                    blocks.append(Block(kind: .paragraph, chars: Array(rest)))
                    firstOnPage = false
                    continue
                }

                if looksLikeHeading(text, lines: par.lines.count, maxSize: maxSize, bodySize: bodySize,
                                    centered: centered, realWords: realWords) {
                    if normalized(text) == normalized(title) { report.removed += 1; continue }
                    blocks.append(Block(kind: .heading, chars: chars))
                    firstOnPage = false
                    continue
                }

                // Is this the rest of a paragraph that started earlier (often on the previous page)?
                if var last = blocks.last, last.kind == .paragraph {
                    let startsLower = text.first?.isLowercase ?? false
                    let lastEnds = last.plain.trimmingCharacters(in: .whitespaces).last
                    let lastFinished = lastEnds.map { ".!?\"”’:".contains($0) } ?? true
                    let continues: Bool
                    if firstOnPage {
                        continues = startsLower || (usesIndents ? !isIndented : !lastFinished)
                    } else {
                        continues = startsLower && !lastFinished
                    }
                    if continues {
                        append(chars, to: &last.chars)
                        blocks[blocks.count - 1] = last
                        firstOnPage = false
                        continue
                    }
                }
                blocks.append(Block(kind: .paragraph, chars: chars))
                firstOnPage = false
            }
        }

        // Tidy each block's text: quotes, spacing, and common letter mistakes.
        return blocks.map { var b = $0; b.chars = tidy(b.chars, report: &report); return b }
            .filter { !$0.plain.trimmingCharacters(in: .whitespaces).isEmpty }
    }

    private static func looksLikeHeading(_ text: String, lines: Int, maxSize: Double, bodySize: Double,
                                         centered: Bool, realWords: Double) -> Bool {
        guard text.count <= 90, lines <= 3 else { return false }
        let range = NSRange(text.startIndex..., in: text)
        if chapterPattern.firstMatch(in: text, range: range) != nil || isChapterLike(text) { return true }
        let letters = text.filter(\.isLetter)
        guard letters.count >= 4, realWords >= 0.5, Double(letters.count) / Double(text.count) > 0.6 else { return false }
        if bodySize > 0 && maxSize >= bodySize * 1.3 { return true }
        if centered && lines == 1 && text.count <= 50 && letters == letters.uppercased() { return true }
        return false
    }

    /// Joins a paragraph's lines, rejoining words that were hyphenated at the end of a line.
    private static func joinLines(_ lines: [ScanLine]) -> [(Character, Bool)] {
        var out: [(Character, Bool)] = []
        for line in lines {
            var chars: [(Character, Bool)] = []
            for run in line.runs { for ch in run.text { chars.append((ch, run.italic)) } }
            while chars.last.map({ $0.0.isWhitespace }) == true { chars.removeLast() }
            while chars.first.map({ $0.0.isWhitespace }) == true { chars.removeFirst() }
            guard !chars.isEmpty else { continue }
            append(chars, to: &out)
        }
        return out
    }

    private static func append(_ next: [(Character, Bool)], to out: inout [(Character, Bool)]) {
        guard let first = next.first else { return }
        if let last = out.last?.0, "-¬\u{00AD}".contains(last), first.0.isLowercase {
            out.removeLast() // "won-" + "derful" → "wonderful"
        } else if !out.isEmpty {
            out.append((" ", false))
        }
        out.append(contentsOf: next)
    }

    /// Straightens out spacing and quotation marks, then fixes common letter mistakes.
    private static func tidy(_ input: [(Character, Bool)], report: inout Report) -> [(Character, Bool)] {
        var chars: [(Character, Bool)] = []
        var quoteOpen = false
        for (ch, it) in input {
            if ch == "\"" || ch == "“" || ch == "”" {
                if quoteOpen {
                    while chars.last?.0 == " " { chars.removeLast() } // no space before a closing quote
                    chars.append(("”", it))
                } else {
                    chars.append(("“", it))
                }
                quoteOpen.toggle()
                continue
            }
            if ch == " " {
                if chars.last?.0 == " " || chars.last?.0 == "“" || chars.isEmpty { continue }
            }
            chars.append((ch == "\t" ? " " : ch, it))
        }
        // Rebuild runs of the same style and fix words inside each run.
        var out: [(Character, Bool)] = []
        var i = 0
        var italicRuns = 0
        while i < chars.count {
            let style = chars[i].1
            var j = i
            while j < chars.count && chars[j].1 == style { j += 1 }
            var piece = String(chars[i..<j].map(\.0))
            EpubCleaner.fixWords(&piece)
            if style && piece.contains(where: \.isLetter) { italicRuns += 1 }
            out.append(contentsOf: piece.map { ($0, style) })
            i = j
        }
        report.italics += italicRuns
        while out.last?.0 == " " { out.removeLast() }
        return out
    }

    // MARK: Chapter headings: tidy names, fix misread numbers

    /// A short line whose first word is close to "chapter" (e.g. a misread "Cha¥ er XIV").
    private static func isChapterLike(_ text: String) -> Bool {
        guard text.count <= 25 else { return false }
        let first = String(text.split(separator: " ").first ?? "").lowercased().filter(\.isLetter)
        return first.count >= 5 && first.count <= 9 && editDistance(first, "chapter") <= 2
    }

    private static func fixHeadings(_ blocks: [Block], report: inout Report) -> [Block] {
        let isChapter: (Block) -> Bool = { b in
            b.kind == .heading && (chapterPattern.firstMatch(in: b.plain, range: NSRange(b.plain.startIndex..., in: b.plain)) != nil
                                   || isChapterLike(b.plain))
        }
        let chapterMode = blocks.filter(isChapter).count >= 5
        var out: [Block] = []
        var lastNumber = 0
        for (i, block) in blocks.enumerated() {
            guard block.kind == .heading else { out.append(block); continue }
            if chapterMode && !isChapter(block) {
                // A stray fragment just before a real chapter heading.
                let next = i + 1 < blocks.count ? blocks[i + 1] : nil
                if let next, isChapter(next), block.plain.filter(\.isLetter).count < 6 { continue }
                // In a book with numbered chapters, only chapters (and a title right under one)
                // count as headings; anything else stays as ordinary text.
                let previous = out.last
                if previous.map({ !isChapter($0) }) ?? true {
                    out.append(Block(kind: .paragraph, chars: block.chars))
                    continue
                }
            }
            guard isChapter(block) else { out.append(block); continue }
            let words = block.plain.split(separator: " ").map(String.init)
            let numeral = words.dropFirst().first.map { $0.trimmingCharacters(in: CharacterSet(charactersIn: ".:,")) } ?? ""
            let word = isChapterLike(block.plain) ? "Chapter" : words[0].capitalized
            var number = romanValue(numeral.replacingOccurrences(of: "l", with: "I").replacingOccurrences(of: "1", with: "I"))
                ?? Int(numeral)
            // A misread number (unreadable, or going backwards / jumping far ahead): use the next number.
            // A small jump is kept, since it usually means one chapter title wasn't detected.
            if lastNumber > 0, word == "Chapter", number.map({ $0 <= lastNumber || $0 > lastNumber + 3 }) ?? true {
                number = lastNumber + 1
            }
            if word == "Chapter", let n = number { lastNumber = n }
            let label = number.map { "\(word) \(roman($0))" } ?? tidyHeading(block.plain)
            out.append(Block(kind: .heading, chars: label.map { ($0, false) }))
        }
        return out
    }

    private static func romanValue(_ s: String) -> Int? {
        let values: [Character: Int] = ["I": 1, "V": 5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000]
        let u = s.uppercased()
        guard !u.isEmpty, u.allSatisfy({ values[$0] != nil }) else { return nil }
        var total = 0, prev = 0
        for ch in u.reversed() {
            let v = values[ch]!
            total += v < prev ? -v : v
            prev = max(prev, v)
        }
        return roman(total) == u ? total : nil
    }

    private static func roman(_ n: Int) -> String {
        let table: [(Int, String)] = [(1000, "M"), (900, "CM"), (500, "D"), (400, "CD"), (100, "C"), (90, "XC"),
                                      (50, "L"), (40, "XL"), (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")]
        var n = n, out = ""
        for (v, s) in table { while n >= v { out += s; n -= v } }
        return out
    }

    private static func editDistance(_ a: String, _ b: String) -> Int {
        let a = Array(a), b = Array(b)
        var row = Array(0...b.count)
        for i in 1...max(a.count, 1) where !a.isEmpty {
            var prev = row[0]; row[0] = i
            for j in 1...b.count {
                let cur = row[j]
                row[j] = min(row[j] + 1, row[j - 1] + 1, prev + (a[i - 1] == b[j - 1] ? 0 : 1))
                prev = cur
            }
        }
        return a.isEmpty ? b.count : row[b.count]
    }

    // MARK: Telling page furniture from real text

    private static func typicalFontSize(_ pages: [ScanPage]) -> Double {
        var counts: [Double: Int] = [:]
        for page in pages {
            for par in page.pars {
                for line in par.lines {
                    for run in line.runs where run.size > 0 {
                        counts[(run.size * 2).rounded() / 2, default: 0] += run.text.count
                    }
                }
            }
        }
        return counts.max { $0.value < $1.value }?.key ?? 0
    }

    /// Text that shows up at the top or bottom of many pages (like the book's title).
    private static func repeatedEdgeLines(_ pages: [ScanPage]) -> Set<String> {
        var counts: [String: Int] = [:]
        for page in pages {
            let pars = page.pars.sorted { $0.top < $1.top }
            for p in [pars.first, pars.last].compactMap({ $0 }) where p.lines.count == 1 {
                let key = normalized(p.lines[0].text)
                if key.count >= 3 { counts[key, default: 0] += 1 }
            }
        }
        return Set(counts.filter { $0.value >= 3 }.keys)
    }

    private static func normalized(_ s: String) -> String {
        String(s.lowercased().filter(\.isLetter))
    }

    private static func isPageNumber(_ s: String) -> Bool {
        let t = s.trimmingCharacters(in: CharacterSet(charactersIn: " .-–—[]()*"))
        guard !t.isEmpty, t.count <= 6 else { return false }
        return t.allSatisfy(\.isNumber) || t.lowercased().allSatisfy { "ivxlc".contains($0) }
    }

    /// Garbled bits from pictures and decorations.
    private static func isJunk(_ s: String) -> Bool {
        let visible = s.filter { !$0.isWhitespace }
        guard !visible.isEmpty else { return true }
        if s.trimmingCharacters(in: .whitespaces).allSatisfy({ "*·•.⁂ ".contains($0) }) && visible.count >= 3 {
            return false // a scene break like "* * *"
        }
        let letters = visible.filter(\.isLetter).count
        if letters < 2 { return true }
        if Double(letters) / Double(visible.count) < 0.6 { return true }
        // Mostly one- and two-letter fragments, like "m '% I 1 omfon"
        let words = s.split(whereSeparator: \.isWhitespace)
        if words.count >= 3 && Double(words.filter { $0.count <= 2 }.count) / Double(words.count) > 0.7 { return true }
        return false
    }

    private static func median(_ values: [Double]) -> Double? {
        guard !values.isEmpty else { return nil }
        let sorted = values.sorted()
        return sorted[sorted.count / 2]
    }

    // MARK: Headings and paragraphs → chapters

    struct Chapter {
        var heading: String?
        var html: String
    }

    private static func splitIntoChapters(_ blocks: [Block]) -> [Chapter] {
        var chapters: [Chapter] = []
        var headingParts: [String] = []
        var html = ""
        var afterHeading = false

        func finish() {
            guard !html.isEmpty || !headingParts.isEmpty else { return }
            chapters.append(Chapter(heading: headingParts.isEmpty ? nil : headingParts.joined(separator: " — "), html: html))
            headingParts = []
            html = ""
        }

        for (i, block) in blocks.enumerated() {
            switch block.kind {
            case .heading:
                // Consecutive headings ("BOOK ONE", "CHAPTER I") belong together.
                let previousWasHeading = i > 0 && blocks[i - 1].kind == .heading
                if !previousWasHeading { finish() }
                headingParts.append(tidyHeading(block.plain))
                html += "<h2>\(inlineHTML(block.chars))</h2>\n"
                afterHeading = true
            case .paragraph:
                let text = block.plain.trimmingCharacters(in: .whitespaces)
                if text.allSatisfy({ "*·•.⁂ ".contains($0) }) {
                    html += "<p class=\"break\">* * *</p>\n"
                    afterHeading = true
                } else {
                    html += "<p\(afterHeading ? " class=\"first\"" : "")>\(inlineHTML(block.chars))</p>\n"
                    afterHeading = false
                }
            }
        }
        finish()

        // A book with no detectable chapters still gets split into readable sections.
        if chapters.count == 1, chapters[0].heading == nil {
            let paras = chapters[0].html.components(separatedBy: "\n").filter { !$0.isEmpty }
            if paras.count > 120 {
                chapters = stride(from: 0, to: paras.count, by: 100).enumerated().map { n, start in
                    Chapter(heading: "Part \(n + 1)",
                            html: paras[start..<min(start + 100, paras.count)].joined(separator: "\n") + "\n")
                }
            }
        }
        return chapters
    }

    private static func tidyHeading(_ s: String) -> String {
        let t = s.trimmingCharacters(in: CharacterSet(charactersIn: " ."))
            .replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)
        guard t.uppercased() == t else { return t }
        return t.split(separator: " ").map { w in
            romanValue(String(w)) != nil && w.count > 1 ? String(w) : w.capitalized
        }.joined(separator: " ")
    }

    private static func inlineHTML(_ chars: [(Character, Bool)]) -> String {
        var out = ""
        var italic = false
        for (ch, it) in chars {
            if it != italic {
                // Keep spaces outside the italic tags.
                if ch == " " { out += " "; continue }
                out += it ? "<i>" : "</i>"
                italic = it
            }
            out += EpubWriter.escape(String(ch))
        }
        if italic { out += "</i>" }
        return out.replacingOccurrences(of: "<i></i>", with: "")
    }
}

/// Writes a standard EPUB 3 file.
enum EpubWriter {

    static func escape(_ s: String) -> String {
        s.replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;")
            .replacingOccurrences(of: "\"", with: "&quot;")
    }

    static func write(title: String, author: String, chapters: [ScanRebuilder.Chapter], to output: URL, work: URL) throws {
        let fm = FileManager.default
        let root = work.appendingPathComponent("epub-\(UUID().uuidString)")
        let oebps = root.appendingPathComponent("OEBPS")
        try fm.createDirectory(at: root.appendingPathComponent("META-INF"), withIntermediateDirectories: true)
        try fm.createDirectory(at: oebps, withIntermediateDirectories: true)

        func save(_ text: String, _ path: String) throws {
            try text.write(to: root.appendingPathComponent(path), atomically: true, encoding: .utf8)
        }

        let t = escape(title), a = escape(author)
        try save("application/epub+zip", "mimetype")
        try save("""
            <?xml version="1.0" encoding="UTF-8"?>
            <container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
              <rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles>
            </container>
            """, "META-INF/container.xml")
        try save(stylesheet, "OEBPS/style.css")
        try save(page(title: t, body: "<section class=\"titlepage\"><h1>\(t)</h1><p class=\"author\">\(a)</p></section>"),
                 "OEBPS/title.xhtml")

        var manifest = """
                <item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
                <item id="css" href="style.css" media-type="text/css"/>
                <item id="title" href="title.xhtml" media-type="application/xhtml+xml"/>

            """
        var spine = "    <itemref idref=\"title\"/>\n"
        var toc = ""
        for (i, chapter) in chapters.enumerated() {
            let file = String(format: "ch%03d.xhtml", i + 1)
            try save(page(title: escape(chapter.heading ?? title), body: chapter.html), "OEBPS/\(file)")
            manifest += "    <item id=\"c\(i + 1)\" href=\"\(file)\" media-type=\"application/xhtml+xml\"/>\n"
            spine += "    <itemref idref=\"c\(i + 1)\"/>\n"
            let label = chapter.heading ?? (i == 0 ? "Beginning" : "Section \(i + 1)")
            toc += "      <li><a href=\"\(file)\">\(escape(label))</a></li>\n"
        }

        try save(page(title: "Contents", body: "<nav epub:type=\"toc\" id=\"toc\"><h2>Contents</h2>\n<ol>\n\(toc)</ol></nav>"),
                 "OEBPS/nav.xhtml")

        let modified = ISO8601DateFormatter().string(from: Date())
        try save("""
            <?xml version="1.0" encoding="UTF-8"?>
            <package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="uid">
              <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
                <dc:identifier id="uid">urn:uuid:\(UUID().uuidString)</dc:identifier>
                <dc:title>\(t)</dc:title>
                <dc:creator>\(a)</dc:creator>
                <dc:language>en</dc:language>
                <meta property="dcterms:modified">\(modified)</meta>
              </metadata>
              <manifest>
            \(manifest)  </manifest>
              <spine>
            \(spine)  </spine>
            </package>
            """, "OEBPS/content.opf")

        // Pack it up. EPUB readers require the "mimetype" file first and uncompressed.
        try? fm.removeItem(at: output)
        try Shell.run("/usr/bin/zip", ["-X", "-0", "-q", output.path, "mimetype"], in: root)
        try Shell.run("/usr/bin/zip", ["-X", "-r", "-9", "-D", "-q", output.path, "META-INF", "OEBPS"], in: root)
    }

    private static func page(title: String, body: String) -> String {
        """
        <?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE html>
        <html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" lang="en" xml:lang="en">
        <head><meta charset="UTF-8"/><title>\(title)</title><link rel="stylesheet" type="text/css" href="style.css"/></head>
        <body>
        \(body)
        </body>
        </html>
        """
    }

    private static let stylesheet = """
        body { margin: 0 5%; line-height: 1.5; font-family: serif; }
        p { margin: 0; text-indent: 1.5em; text-align: justify; hyphens: auto; -webkit-hyphens: auto; }
        p.first, p.break + p { text-indent: 0; }
        p.break { text-align: center; text-indent: 0; margin: 1em 0; }
        h1 { text-align: center; margin-top: 30%; font-size: 1.8em; }
        h2 { text-align: center; font-size: 1.25em; margin: 2.5em 0 1.5em; page-break-before: always; break-before: page; }
        h2 + h2 { margin-top: 0; page-break-before: avoid; break-before: avoid; }
        .titlepage .author { text-align: center; text-indent: 0; font-style: italic; margin-top: 1em; }
        nav ol { list-style: none; padding: 0; }
        nav li { margin: 0.4em 0; }
        """
}
