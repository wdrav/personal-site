#if canImport(SwiftUI)
import SwiftUI
import AppKit

struct ContentView: View {
    @State private var query = ""
    @State private var results: [Book] = []
    @State private var isSearching = false
    @State private var message: String?
    @State private var downloading: Set<String> = []
    @State private var saved: [String: URL] = [:]
    @AppStorage("cleanBooks") private var cleanBooks = true

    private var trimmedQuery: String { query.trimmingCharacters(in: .whitespaces) }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                TextField("Search for a book title…", text: $query)
                    .textFieldStyle(.roundedBorder)
                    .onSubmit { Task { await runSearch() } }
                Button("Search") { Task { await runSearch() } }
                    .disabled(trimmedQuery.isEmpty || isSearching)
            }

            Text(message ?? " ")
                .font(.callout)
                .foregroundStyle(.secondary)
                .lineLimit(3)
                .frame(maxWidth: .infinity, minHeight: 50, alignment: .topLeading)

            Group {
                if isSearching {
                    ProgressView("Searching…")
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if results.isEmpty {
                    Text("Type a title above and press Return.")
                        .foregroundStyle(.tertiary)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 8) {
                            ForEach(results) { book in
                                row(for: book)
                                Divider()
                            }
                        }
                    }
                }
            }
            .frame(height: 320)

            Toggle("Rebuild scanned books for proper formatting", isOn: $cleanBooks)
                .font(.callout)

            Divider()
            HStack {
                Button("Not here? Search Open Library") { openOpenLibrary() }
                    .buttonStyle(.link)
                Spacer()
                Button("Quit") { NSApplication.shared.terminate(nil) }
            }
            .font(.caption)
        }
        .padding(12)
        .frame(width: 380)
    }

    @ViewBuilder
    private func row(for book: Book) -> some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 2) {
                Text(book.title).font(.headline).lineLimit(2)
                if !book.author.isEmpty {
                    Text(book.author).font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
                }
                Text(book.source.note).font(.caption).foregroundStyle(.tertiary)
            }
            Spacer()
            if let file = saved[book.id] {
                Button("Show") { NSWorkspace.shared.activateFileViewerSelecting([file]) }
            } else if downloading.contains(book.id) {
                ProgressView().controlSize(.small)
            } else {
                Button("Download") { Task { await download(book) } }
            }
        }
    }

    @MainActor
    private func runSearch() async {
        guard !trimmedQuery.isEmpty else { return }
        isSearching = true
        message = nil
        results = await BookSearch.search(trimmedQuery)
        isSearching = false
        if results.isEmpty {
            message = "No free EPUBs found. Newer books usually aren't free — try the Open Library link below to borrow it."
        }
    }

    @MainActor
    private func download(_ book: Book) async {
        downloading.insert(book.id)
        do {
            let result = try await BookSearch.download(book, improve: cleanBooks)
            saved[book.id] = result.file
            message = "Saved “\(book.title)” to Downloads. \(result.summary)"
        } catch {
            message = "Couldn't download that one: \(error.localizedDescription)"
        }
        downloading.remove(book.id)
    }

    private func openOpenLibrary() {
        var c = URLComponents(string: "https://openlibrary.org/search")!
        c.queryItems = [URLQueryItem(name: "q", value: trimmedQuery)]
        if let url = c.url { NSWorkspace.shared.open(url) }
    }
}
#endif
