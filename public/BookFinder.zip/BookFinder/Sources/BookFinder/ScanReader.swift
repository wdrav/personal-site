import Foundation
#if canImport(FoundationXML)
import FoundationXML
#endif

/// One piece of text with a single style.
struct ScanRun {
    var text: String
    var italic: Bool
    var size: Double
}

struct ScanLine {
    var left: Double, top: Double, right: Double, bottom: Double
    var runs: [ScanRun] = []
    /// How many words the scanner recognised, and how many were real dictionary words.
    var words = 0
    var dictionaryWords = 0
    var hasDictionaryInfo = false
    var text: String { runs.map(\.text).joined() }
}

struct ScanPar {
    var lines: [ScanLine] = []
    var top: Double { lines.first?.top ?? 0 }
}

struct ScanPage {
    var width: Double
    var height: Double
    var pars: [ScanPar] = []
}

/// Reads the Internet Archive's page-layout files: ABBYY XML (has italics and
/// font sizes) or hOCR (has font sizes only). Both describe each scanned page
/// as paragraphs, lines and words, with their positions on the page.
enum ScanReader {
    enum Kind { case abbyy, hocr }

    static func read(_ file: URL, kind: Kind) throws -> [ScanPage] {
        guard let parser = XMLParser(contentsOf: file) else { throw BookError.noEPUB }
        parser.shouldResolveExternalEntities = false
        let delegate: LayoutDelegate = kind == .abbyy ? ABBYYDelegate() : HOCRDelegate()
        parser.delegate = delegate
        _ = parser.parse()
        // A truncated or slightly broken file still gives us the pages read so far.
        guard !delegate.pages.isEmpty else { throw parser.parserError ?? BookError.noEPUB }
        return delegate.pages
    }
}

class LayoutDelegate: NSObject, XMLParserDelegate {
    var pages: [ScanPage] = []

    // Subclasses fill these in. (Declaring them here makes sure the parser calls them on every system.)
    func parser(_ parser: XMLParser, didStartElement name: String, namespaceURI: String?,
                qualifiedName: String?, attributes a: [String: String] = [:]) {}
    func parser(_ parser: XMLParser, foundCharacters string: String) {}
    func parser(_ parser: XMLParser, didEndElement name: String, namespaceURI: String?, qualifiedName: String?) {}
}

// MARK: ABBYY FineReader XML

private final class ABBYYDelegate: LayoutDelegate {
    private var page: ScanPage?
    private var inTextBlock = false
    private var par: ScanPar?
    private var line: ScanLine?
    private var run: ScanRun?
    private var inChar = false

    override func parser(_ parser: XMLParser, didStartElement name: String, namespaceURI: String?,
                qualifiedName: String?, attributes a: [String: String] = [:]) {
        switch name {
        case "page":
            page = ScanPage(width: num(a["width"]), height: num(a["height"]))
        case "block":
            inTextBlock = (a["blockType"] ?? "Text") == "Text"
        case "par":
            if inTextBlock { par = ScanPar() }
        case "line":
            if par != nil {
                line = ScanLine(left: num(a["l"]), top: num(a["t"]), right: num(a["r"]), bottom: num(a["b"]))
            }
        case "formatting":
            if line != nil {
                run = ScanRun(text: "", italic: a["italic"] == "true" || a["italic"] == "1", size: num(a["fs"]))
            }
        case "charParams":
            inChar = true
            if a["wordStart"] == "true" {
                line?.words += 1
                if let d = a["wordFromDictionary"] {
                    line?.hasDictionaryInfo = true
                    if d == "true" { line?.dictionaryWords += 1 }
                }
            }
        default: break
        }
    }

    override func parser(_ parser: XMLParser, foundCharacters string: String) {
        guard run != nil else { return }
        // Text normally sits inside charParams; skip the line breaks between tags.
        if inChar || !string.contains("\n") { run?.text += string }
    }

    override func parser(_ parser: XMLParser, didEndElement name: String, namespaceURI: String?, qualifiedName: String?) {
        switch name {
        case "charParams": inChar = false
        case "formatting":
            if let r = run, !r.text.isEmpty { line?.runs.append(r) }
            run = nil
        case "line":
            if let l = line, !l.runs.isEmpty { par?.lines.append(l) }
            line = nil
        case "par":
            if let p = par, !p.lines.isEmpty { page?.pars.append(p) }
            par = nil
        case "block": inTextBlock = false
        case "page":
            if let p = page { pages.append(p) }
            page = nil
        default: break
        }
    }
}

// MARK: hOCR (HTML with layout info in the title attributes)

private final class HOCRDelegate: LayoutDelegate {
    private enum Role { case page, par, line, word, italic, skip, other }
    private var stack: [Role] = []
    private var page: ScanPage?
    private var par: ScanPar?
    private var line: ScanLine?
    private var lineSize = 0.0
    private var word: ScanRun?
    private var italicDepth = 0
    private var skipDepth = 0

    override func parser(_ parser: XMLParser, didStartElement name: String, namespaceURI: String?,
                qualifiedName: String?, attributes a: [String: String] = [:]) {
        let cls = a["class"] ?? ""
        let title = a["title"] ?? ""
        var role = Role.other
        if skipDepth > 0 || cls == "ocr_photo" || cls == "ocr_image" || cls == "ocr_separator" {
            role = .skip
            skipDepth += 1
        } else if cls == "ocr_page" {
            let box = bbox(title)
            page = ScanPage(width: box[2], height: box[3])
            role = .page
        } else if cls == "ocr_par" {
            par = ScanPar()
            role = .par
        } else if ["ocr_line", "ocr_header", "ocr_textfloat", "ocr_caption"].contains(cls) {
            let box = bbox(title)
            line = ScanLine(left: box[0], top: box[1], right: box[2], bottom: box[3])
            lineSize = field("x_fsize", title) ?? 0
            role = .line
            if par == nil { par = ScanPar() } // some files have lines outside paragraphs
        } else if cls == "ocrx_word" {
            word = ScanRun(text: "", italic: italicDepth > 0, size: field("x_fsize", title) ?? lineSize)
            role = .word
        } else if name == "em" || name == "i" {
            italicDepth += 1
            word?.italic = true
            role = .italic
        }
        stack.append(role)
    }

    override func parser(_ parser: XMLParser, foundCharacters string: String) {
        guard skipDepth == 0, word != nil else { return }
        word?.text += string
    }

    override func parser(_ parser: XMLParser, didEndElement name: String, namespaceURI: String?, qualifiedName: String?) {
        guard let role = stack.popLast() else { return }
        switch role {
        case .skip: skipDepth -= 1
        case .italic: italicDepth -= 1
        case .word:
            if var w = word {
                w.text = w.text.trimmingCharacters(in: .whitespacesAndNewlines)
                if !w.text.isEmpty {
                    if var l = line {
                        if let last = l.runs.last, !last.text.hasSuffix(" ") {
                            l.runs[l.runs.count - 1].text += " "
                        }
                        l.runs.append(w)
                        line = l
                    }
                }
            }
            word = nil
        case .line:
            if var l = line, !l.runs.isEmpty {
                l.runs[l.runs.count - 1].text = l.runs[l.runs.count - 1].text.trimmingCharacters(in: .whitespaces)
                par?.lines.append(l)
            }
            line = nil
            // Lines that weren't inside a paragraph become their own paragraph.
            if !stack.contains(.par), let p = par {
                if !p.lines.isEmpty { page?.pars.append(p) }
                par = nil
            }
        case .par:
            if let p = par, !p.lines.isEmpty { page?.pars.append(p) }
            par = nil
        case .page:
            if let p = page { pages.append(p) }
            page = nil
        case .other: break
        }
    }

    private func bbox(_ title: String) -> [Double] {
        for part in title.split(separator: ";") {
            let bits = part.split(separator: " ")
            if bits.first == "bbox", bits.count >= 5 { return bits[1...4].map { Double($0) ?? 0 } }
        }
        return [0, 0, 0, 0]
    }

    private func field(_ key: String, _ title: String) -> Double? {
        for part in title.split(separator: ";") {
            let bits = part.split(separator: " ")
            if bits.first.map(String.init) == key, bits.count >= 2 { return Double(bits[1]) }
        }
        return nil
    }
}

private func num(_ s: String?) -> Double {
    guard var s else { return 0 }
    if s.hasSuffix(".") { s.removeLast() }
    return Double(s) ?? 0
}
