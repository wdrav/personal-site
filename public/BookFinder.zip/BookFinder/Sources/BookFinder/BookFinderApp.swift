#if canImport(SwiftUI)
import SwiftUI
import AppKit

@main
struct BookFinderApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    // No regular windows; everything lives in the menu bar icon.
    var body: some Scene {
        Settings { EmptyView() }
    }
}

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate {
    private var statusItem: NSStatusItem?
    private let popover = NSPopover()
    private var window: NSWindow?

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory) // menu bar only, no Dock icon

        let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        item.isVisible = true
        if let button = item.button {
            if let image = NSImage(systemSymbolName: "book.fill", accessibilityDescription: "Book Finder") {
                image.isTemplate = true
                button.image = image
            } else {
                button.title = "Books"
            }
            button.target = self
            button.action = #selector(togglePopover)
        }
        statusItem = item

        popover.behavior = .transient
        popover.contentViewController = NSHostingController(rootView: ContentView())

        // Show a window the first time so it's obvious the app started,
        // even if the menu bar is too crowded to show the icon.
        showWindow()
    }

    @objc private func togglePopover() {
        guard let button = statusItem?.button else { return }
        if popover.isShown {
            popover.performClose(nil)
        } else {
            NSApp.activate(ignoringOtherApps: true)
            popover.show(relativeTo: button.bounds, of: button, preferredEdge: .minY)
            popover.contentViewController?.view.window?.makeKey()
        }
    }

    // Opening the app again (from Applications, Spotlight, or Terminal) brings up the window.
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        showWindow()
        return false
    }

    private func showWindow() {
        if window == nil {
            let w = NSWindow(contentViewController: NSHostingController(rootView: ContentView()))
            w.title = "Book Finder"
            w.styleMask = [.titled, .closable, .miniaturizable]
            w.isReleasedWhenClosed = false
            w.center()
            window = w
        }
        NSApp.activate(ignoringOtherApps: true)
        window?.makeKeyAndOrderFront(nil)
    }
}
#endif
