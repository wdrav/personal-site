#if !canImport(SwiftUI)
import Foundation

/// Test harness used only when building on Linux (no Mac interface available).
/// Usage: BookFinder search <title> | rebuild <abbyy.xml|hocr.html> <out.epub> | download <source> <title>
@main
struct LinuxCheck {
    static func main() async throws {
        let args = Array(CommandLine.arguments.dropFirst())
        switch args.first {
        case "search":
            let q = args.dropFirst().joined(separator: " ")
            for s in Source.allCases {
                let r: [Book]
                switch s {
                case .standardEbooks: r = (try? await BookSearch.standardEbooks(q)) ?? []
                case .gutenberg: r = (try? await BookSearch.gutenberg(q)) ?? []
                case .wikisource: do { r = try await BookSearch.wikisource(q) } catch { print("wikisource error:", error); r = [] }
                case .archive: r = (try? await BookSearch.archive(q)) ?? []
                }
                print("\(s.rawValue): \(r.count) results")
                for b in r.prefix(3) { print("   \(b.title) | \(b.author) | \(b.downloadURL?.absoluteString ?? b.archiveID ?? "")") }
            }
        case "rebuild":
            let input = URL(fileURLWithPath: args[1])
            let start = Date()
            let pages = try ScanReader.read(input, kind: input.pathExtension == "html" ? .hocr : .abbyy)
            let read = Date().timeIntervalSince(start)
            print("read \(pages.count) pages, \(pages.reduce(0) { $0 + $1.pars.count }) paragraphs, \(pages.reduce(0) { $0 + $1.pars.reduce(0) { $0 + $1.lines.count } }) lines")
            let work = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
            try FileManager.default.createDirectory(at: work, withIntermediateDirectories: true)
            let r = try ScanRebuilder.rebuild(pages: pages, title: "Test Book", author: "Test Author",
                                              to: URL(fileURLWithPath: args[2]), work: work)
            print("pages \(pages.count), read \(String(format: "%.1f", read))s, total \(String(format: "%.1f", Date().timeIntervalSince(start)))s")
            print("chapters \(r.chapters), paragraphs \(r.paragraphs), italics \(r.italics), removed \(r.removed)")
        case "download":
            let source = Source.allCases.first { $0.rawValue.lowercased().hasPrefix(args[1].lowercased()) }!
            let q = args.dropFirst(2).joined(separator: " ")
            let found = await BookSearch.search(q).filter { $0.source == source }
            guard let book = found.first else { print("nothing found"); return }
            let start = Date()
            let result = try await BookSearch.download(book, improve: true,
                                                       to: URL(fileURLWithPath: FileManager.default.currentDirectoryPath))
            print("\(book.title) -> \(result.file.lastPathComponent) in \(String(format: "%.1f", Date().timeIntervalSince(start)))s")
            print(result.summary)
        default:
            print("usage: search <q> | rebuild <file> <out.epub> | download <source> <q>")
        }
    }
}
#endif
