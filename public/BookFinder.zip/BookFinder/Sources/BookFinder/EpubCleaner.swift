import Foundation
#if canImport(FoundationXML)
import FoundationXML
#endif

/// Fixes common problems in EPUBs made from scanned pages (Internet Archive books):
/// words split by line-end hyphens, paragraphs broken mid-sentence, stray page
/// numbers, odd characters, and frequent letter-recognition mistakes.
enum EpubCleaner {

    /// Cleans `input` and writes the result to `output`. Returns how many fixes were made.
    static func clean(_ input: URL, to output: URL) throws -> Int {
        let fm = FileManager.default
        let work = fm.temporaryDirectory.appendingPathComponent("bookfinder-\(UUID().uuidString)")
        try fm.createDirectory(at: work, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: work) }

        // An EPUB is a zip file of web pages; unpack it.
        try Shell.run("/usr/bin/unzip", ["-q", "-o", input.path, "-d", work.path], okCodes: [0, 1])

        var fixes = 0
        let pageTypes: Set<String> = ["xhtml", "html", "htm"]
        if let files = fm.enumerator(at: work, includingPropertiesForKeys: nil) {
            for case let file as URL in files where pageTypes.contains(file.pathExtension.lowercased()) {
                guard var page = try? String(contentsOf: file, encoding: .utf8) else { continue }
                let n = cleanPage(&page)
                if n > 0 {
                    try page.write(to: file, atomically: true, encoding: .utf8)
                    fixes += n
                }
            }
        }

        // Repack. EPUB readers require the "mimetype" file first and uncompressed.
        let mimetype = work.appendingPathComponent("mimetype")
        if !fm.fileExists(atPath: mimetype.path) {
            try "application/epub+zip".write(to: mimetype, atomically: true, encoding: .ascii)
        }
        try? fm.removeItem(at: output)
        try Shell.run("/usr/bin/zip", ["-X", "-0", "-q", output.path, "mimetype"], in: work)
        try Shell.run("/usr/bin/zip", ["-X", "-r", "-9", "-D", "-q", output.path, ".", "-x", "mimetype"], in: work)
        return fixes
    }

    // MARK: Cleaning one page

    static func cleanPage(_ page: inout String) -> Int {
        // Only touch the visible part of the page, never the styling in <head>.
        guard let bodyStart = page.range(of: "<body") else { return 0 }
        let head = String(page[..<bodyStart.lowerBound])
        var body = String(page[bodyStart.lowerBound...])
        var n = 0

        let para = #"<p(?:\s[^>]*)?>"#
        // Stray page numbers sitting in their own paragraph, e.g. "<p>127</p>".
        n += replace(para + #"\s*\[?\s*\d{1,4}\s*\]?\s*</p>"#, with: "", in: &body)
        // A word split by a hyphen across two paragraphs or a line break: "won- / derful".
        n += replace(#"([a-z])-\s*</p>\s*"# + para + #"\s*([a-z])"#, with: "$1$2", in: &body)
        n += replace(#"([a-z])-\s*<br\s*/?>\s*([a-z])"#, with: "$1$2", in: &body)
        // A paragraph broken mid-sentence (ends without punctuation, next starts lowercase).
        n += replace(#"([a-z,;])\s*</p>\s*"# + para + #"\s*([a-z])"#, with: "$1 $2", in: &body)

        n += transformText(&body) { text in fixWords(&text) }

        page = head + body
        return n
    }


    /// Fixes typical scanning mistakes in a piece of plain text. Returns how many fixes were made.
    @discardableResult
    static func fixWords(_ text: inout String) -> Int {
        var c = 0
        // Special combined letters and invisible characters.
        for (bad, good) in [("ﬁ", "fi"), ("ﬂ", "fl"), ("ﬀ", "ff"), ("ﬃ", "ffi"), ("ﬄ", "ffl"),
                            ("\u{00AD}", ""), ("\u{200B}", ""), ("\u{FEFF}", "")] {
            c += replace(NSRegularExpression.escapedPattern(for: bad), with: good, in: &text)
        }
        // Hyphenated word broken across a line inside a paragraph.
        c += replace(#"([a-z])-[ \t]*\r?\n\s*([a-z])"#, with: "$1$2", in: &text)
        // Frequent letter-recognition mistakes.
        for (bad, good) in [("tbe", "the"), ("tlie", "the"), ("Tbe", "The"), ("Tlie", "The"),
                            ("tliat", "that"), ("tbat", "that"), ("wliich", "which"), ("wbich", "which"),
                            ("witb", "with"), ("liis", "his"), ("mucb", "much"), ("tbey", "they"),
                            ("tliey", "they"), ("wlien", "when"), ("wben", "when"), ("bave", "have")] {
            c += replace(#"\b"# + bad + #"\b"#, with: good, in: &text)
        }
        c += replace(#"(?<= )l(?= )"#, with: "I", in: &text) // a lone "l" is almost always "I"
        // Spaces before punctuation, and doubled spaces.
        c += replace(#"[ \t]+([,.;:!?])(?=\s|$)"#, with: "$1", in: &text)
        replace(#"[ \t]{2,}"#, with: " ", in: &text)
        return c
    }

    // MARK: Helpers

    private static let tag = try! NSRegularExpression(pattern: "<[^>]*>")

    /// Applies `fix` to the words between tags, leaving the tags themselves alone.
    private static func transformText(_ html: inout String, _ fix: (inout String) -> Int) -> Int {
        let ns = html as NSString
        var out = ""
        var last = 0
        var count = 0
        for m in tag.matches(in: html, range: NSRange(location: 0, length: ns.length)) {
            var text = ns.substring(with: NSRange(location: last, length: m.range.location - last))
            count += fix(&text)
            out += text + ns.substring(with: m.range)
            last = m.range.location + m.range.length
        }
        var tail = ns.substring(from: last)
        count += fix(&tail)
        html = out + tail
        return count
    }

    @discardableResult
    private static func replace(_ pattern: String, with template: String, in s: inout String) -> Int {
        guard let re = try? NSRegularExpression(pattern: pattern) else { return 0 }
        let range = NSRange(s.startIndex..., in: s)
        let count = re.numberOfMatches(in: s, range: range)
        if count > 0 { s = re.stringByReplacingMatches(in: s, range: range, withTemplate: template) }
        return count
    }
}
